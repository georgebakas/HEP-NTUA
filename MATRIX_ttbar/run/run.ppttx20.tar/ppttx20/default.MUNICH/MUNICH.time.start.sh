echo 'LO/20/born'
cd LO/20/born
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO/20/born'
cd NLO/20/born
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.CS/30/VA.QCD'
cd NLO.CS/30/VA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.CS/30/CA.QCD'
cd NLO.CS/30/CA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.CS/30/RA.QCD'
cd NLO.CS/30/RA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.QT/30/VT.QCD'
cd NLO.QT/30/VT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.QT/30/CT.QCD'
cd NLO.QT/30/CT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.QT/30/RT.QCD'
cd NLO.QT/30/RT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO/20/born'
cd NNLO/20/born
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.CS/30/VA.QCD'
cd NNLO.CS/30/VA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.CS/30/CA.QCD'
cd NNLO.CS/30/CA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.CS/30/RA.QCD'
cd NNLO.CS/30/RA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT/30/VT.QCD'
cd NNLO.QT/30/VT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT/30/CT.QCD'
cd NNLO.QT/30/CT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT/30/RT.QCD'
cd NNLO.QT/30/RT.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/VT2.QCD'
cd NNLO.QT-CS/40/VT2.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/CT2.QCD'
cd NNLO.QT-CS/40/CT2.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/RVA.QCD'
cd NNLO.QT-CS/40/RVA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/RCA.QCD'
cd NNLO.QT-CS/40/RCA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/RRA.QCD'
cd NNLO.QT-CS/40/RRA.QCD
echo 'time'
cd time
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

