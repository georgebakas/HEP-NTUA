echo 'LO/20/born'
cd LO/20/born
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.CS/30/CA.QCD'
cd NLO.CS/30/CA.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.CS/30/RA.QCD'
cd NLO.CS/30/RA.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.QT/30/CT.QCD'
cd NLO.QT/30/CT.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NLO.QT/30/RT.QCD'
cd NLO.QT/30/RT.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/CT2.QCD'
cd NNLO.QT-CS/40/CT2.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/RCA.QCD'
cd NNLO.QT-CS/40/RCA.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

echo 'NNLO.QT-CS/40/RRA.QCD'
cd NNLO.QT-CS/40/RRA.QCD
echo 'grid'
cd grid
../../../../MUNICH.start.sh
cd ..
cd ../../../
echo

