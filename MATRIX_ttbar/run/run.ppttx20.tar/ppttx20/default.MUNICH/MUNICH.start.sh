MUNICH.start.mogon.sh
